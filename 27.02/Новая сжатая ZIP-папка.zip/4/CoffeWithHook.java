public class CoffeWithHook extends CaffeineBeverageWithHook
    {
    

        void addCondiments()
        {
            System.out.println("Adding Sugar and Milk");
        }

        

        void brew()
        {
            System.out.println("Dripping coffee through filter");
        }

        boolean customerWantsCondiments()
        {
            string answer = getUserInput();

            if (answer.toLowerCase().startWith("y"))
            {
                return true;

            }
            else
            {
                return false;
            }
        }
        
        private string getUserInput()
        {
            string answer = null;

            System.out.println("W");

            BufferedReader in = new BufferedReader(new InputStreamerReader(System.in));
            try
            {
                answer = in.readLine();

            }catch(IOException ioe)
            {
                System.err.println("IO err to read");

            }
            if (answer == null)
            {
                return "no";
            }
            return answer;
        }
    }
