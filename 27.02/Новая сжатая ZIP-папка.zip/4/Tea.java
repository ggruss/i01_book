public class Tea extends CaffeineBeverage
    {

        void addCondiments()
        {
            System.out.println("Adding lemon");
        }

        

        void brew()
        {
            System.out.println("Steeping the tea");
        }

        
    }
