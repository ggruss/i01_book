public class Coffe extends CaffeineBeverage
    {
    

        void addCondiments()
        {
            System.out.println("Adding Sugar and Milk");
        }

        

        void brew()
        {
            System.out.println("Dripping coffee through filter");
        }

        
    }

